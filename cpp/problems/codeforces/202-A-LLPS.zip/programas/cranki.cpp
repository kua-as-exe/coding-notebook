#include <bits/stdc++.h>
using namespace std;

#define all(a) a.begin(), a.end()

int main(){
  string s; cin >> s; 

  sort(all(s));
  string x(1, *(s.end()-1));
  cout << s.substr(s.find(x), s.size()) << endl;
  return 0;
}
