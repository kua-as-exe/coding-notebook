#include<stdio.h>
#include<string.h>
#include<algorithm>

char cad[12];
using namespace std;

int main(){
    int n,x,y,mx;
    x=y=n=mx=0;

    gets(cad);

    n=strlen(cad);
    sort(cad,cad+n);
    puts(cad);
    char mn=cad[n-1];
    mx=n-1;
    while(mn==cad[mx]){
        printf("%c",cad[mx]);
        mx--;
    }



}
