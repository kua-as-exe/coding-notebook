n = int(input())
print(n)