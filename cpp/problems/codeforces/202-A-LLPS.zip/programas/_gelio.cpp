#include<stdio.h>



int cad[12];


int main(){
    int n,x,y;
    x=y=n=0;
    for(x=0;)
    




}