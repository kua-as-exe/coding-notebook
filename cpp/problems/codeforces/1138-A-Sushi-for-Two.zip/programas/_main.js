const print = (text) => process.stdout.write(text);

function main(input){
  let n = input[0];
  print(n);
}

module.exports={main}