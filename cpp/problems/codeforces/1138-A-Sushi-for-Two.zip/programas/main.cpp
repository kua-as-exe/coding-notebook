#include <bits/stdc++.h>
using namespace std;

int n, r, m = 0, k, l;
int main(){
  cin >> n;
  int x[n];
  for(int i = 0; i < n; i++){
    cin >> x[i];
  }

  for(int i = 0; i < n-1; i++){
    if(x[i] != x[i+1]){
      //printf("~ %d & %d ~\n", i, i+1);
      int a = i, b = i+1;
      while(a >= 0 && b < n){
        if(x[i] != x[a] || x[i+1] != x[b])
          break;
        a--;
        b++;
      }
      //printf("  %d - %d\n", a, b);
      l = b-a-1;
      if(l > m) m = l; 

    }

  }

  cout << m;
  return 0;
}